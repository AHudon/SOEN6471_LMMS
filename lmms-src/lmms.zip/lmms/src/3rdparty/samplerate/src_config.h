#include "lmmsconfig.h"

#ifdef LMMS_HAVE_STDINT_H
#define HAVE_STDINT_H
#endif

#define PACKAGE "libsamplerate"
#define VERSION "0.1.7"
